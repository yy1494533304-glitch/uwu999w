// --- 核心聊天逻辑 (js/chat.js) ---
// 此文件保留核心入口和胶水代码，具体功能已拆分至 js/modules/chat_*.js

// 全局函数：显示红包详情
window.showRedPacketDetails = function(message, chat) {
    const modal = document.getElementById('red-packet-details-modal');
    if (!modal) return;

    const amountElem = document.getElementById('red-packet-modal-amount');
    const infoElem = document.getElementById('red-packet-modal-info');
    const listElem = document.getElementById('red-packet-detail-list');

    // 设置金额
    let myAmount = 0;
    if (message.distributions && message.distributions['user_me']) {
        myAmount = message.distributions['user_me'];
    }
    amountElem.innerHTML = `${myAmount.toFixed(2)}<span>元</span>`;

    // 设置信息
    const totalCount = message.count || 1;
    const grabbedCount = message.distributions ? Object.keys(message.distributions).length : 0;
    infoElem.textContent = `共 ${totalCount} 个红包，已领取 ${grabbedCount}/${totalCount} 个`;

    // 渲染列表
    listElem.innerHTML = '';
    if (message.distributions) {
        // 找出运气王
        let maxAmount = 0;
        let luckyId = null;
        Object.entries(message.distributions).forEach(([id, amt]) => {
            if (amt > maxAmount) {
                maxAmount = amt;
                luckyId = id;
            }
        });

        Object.entries(message.distributions).forEach(([memId, amt]) => {
            let name = '未知成员';
            let avatar = 'https://i.postimg.cc/Y96LPskq/o-o-2.jpg';
            
            if (memId === 'user_me') {
                name = chat.me ? chat.me.nickname : '我';
                avatar = chat.me ? chat.me.avatar : 'https://i.postimg.cc/GtbTnxhP/o-o-1.jpg';
            } else {
                const member = chat.members ? chat.members.find(m => m.id === memId) : null;
                if (member) {
                    name = member.groupNickname;
                    avatar = member.avatar;
                }
            }
            
            const isLucky = memId === luckyId;
            const timeStr = new Date(message.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});

            const itemDiv = document.createElement('div');
            itemDiv.className = 'red-packet-detail-item';
            itemDiv.innerHTML = `
                <div class="red-packet-detail-user">
                    <img src="${avatar}" class="red-packet-detail-avatar">
                    <div class="red-packet-detail-name-time">
                        <span class="red-packet-detail-name">${name}</span>
                        <span class="red-packet-detail-time">${timeStr}</span>
                    </div>
                </div>
                <div class="red-packet-detail-amount-box">
                    <span class="red-packet-detail-amount">${amt.toFixed(2)}元</span>
                    ${isLucky ? '<span class="red-packet-detail-luck"><svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/></svg>运气王</span>' : ''}
                </div>
            `;
            listElem.appendChild(itemDiv);
        });
    }

    modal.classList.add('visible');
};

function setupChatRoom() {
    // 重新获取 DOM 元素，因为它们可能是动态注入的
    chatRoomScreen = document.getElementById('chat-room-screen');
    chatExpansionPanel = document.getElementById('chat-expansion-panel');
    panelFunctionArea = document.getElementById('panel-function-area');
    panelStickerArea = document.getElementById('panel-sticker-area');
    messageArea = document.getElementById('message-area');
    chatRoomHeaderDefault = document.getElementById('chat-room-header-default');
    chatRoomHeaderSelect = document.getElementById('chat-room-header-select');
    multiSelectBar = document.getElementById('multi-select-bar');
    multiSelectTitle = document.getElementById('multi-select-title');
    selectCount = document.getElementById('select-count');
    deleteSelectedBtn = document.getElementById('delete-selected-btn');
    chatRoomTitle = document.getElementById('chat-room-title');
    chatRoomStatusText = document.getElementById('chat-room-status-text');
    typingIndicator = document.getElementById('typing-indicator');
    messageInput = document.getElementById('message-input');
    getReplyBtn = document.getElementById('get-reply-btn');
    regenerateBtn = document.getElementById('regenerate-btn');

    const memoryJournalBtn = document.getElementById('memory-journal-btn');
    const deleteHistoryBtn = document.getElementById('delete-history-btn');
    const captureBtn = document.getElementById('capture-btn');
    const toggleExpansionBtn = document.getElementById('toggle-expansion-btn');
    const charStatusBtn = document.getElementById('char-status-btn');
    const statusOverlay = document.getElementById('char-status-overlay');
    const closeStatusBtn = document.getElementById('close-status-panel-btn');
    const statusContent = document.getElementById('char-status-content');

    if(charStatusBtn)charStatusBtn.addEventListener('click',()=>window.ReplyDetails.open(currentChatId));
    if (closeStatusBtn) {
        closeStatusBtn.addEventListener('click', () => {
            statusOverlay.classList.remove('visible');
        });
    }
    
    if (statusOverlay) {
        statusOverlay.addEventListener('click', (e) => {
            if (e.target === statusOverlay) {
                statusOverlay.classList.remove('visible');
            }
        });
    }

    // 状态栏交互事件委托
    if (statusContent) {
        statusContent.addEventListener('click', (e) => {
            const target = e.target.closest('[data-send-msg]');
            if (target) {
                const msg = target.dataset.sendMsg;
                if (msg) {
                    const input = document.getElementById('message-input');
                    if (input) {
                        input.value = msg;
                        document.getElementById('send-message-btn').click();
                        // 关闭状态栏面板
                        statusOverlay.classList.remove('visible');
                    }
                }
            }
        });
    }

    if (toggleExpansionBtn) {
        toggleExpansionBtn.addEventListener('click', () => {
            if (chatExpansionPanel.classList.contains('visible') && panelFunctionArea.style.display !== 'none') {
                showPanel('none');
            } else {
                showPanel('function');
            }
        });
    }

    const vectorMemoryBtn=document.getElementById('vector-memory-btn');
    if(vectorMemoryBtn)vectorMemoryBtn.addEventListener('click',()=>{
        const chat=currentChatType==='private'?db.characters.find(c=>c.id===currentChatId):db.groups.find(c=>c.id===currentChatId);
        if(chat){window.VectorMemoryUI.open(chat);showPanel('none');}
    });
    if (memoryJournalBtn) {
        memoryJournalBtn.addEventListener('click', () => {
            renderJournalList();
            switchScreen('memory-journal-screen');
            showPanel('none'); 
        });
    }

    if (deleteHistoryBtn) {
        deleteHistoryBtn.addEventListener('click', () => {
            openDeleteChunkModal();
            showPanel('none'); 
        });
    }

    if (captureBtn) {
        captureBtn.addEventListener('click', () => {
            enterMultiSelectMode(null, 'capture');
            showPanel('none');
        });
    }

    const shopBtn = document.getElementById('shop-btn');
    if (shopBtn) {
        shopBtn.addEventListener('click', () => {
            if (typeof openShopScreen === 'function') {
                openShopScreen();
                showPanel('none');
            } else {
                showToast('商城模块未加载');
            }
        });
    }

    const videoCallBtn = document.getElementById('video-call-btn');
    if (videoCallBtn) {
        videoCallBtn.addEventListener('click', () => {
            if (window.VideoCallModule) {
                window.VideoCallModule.showCallTypeModal();
                showPanel('none');
            } else {
                showToast('视频通话模块未加载');
            }
        });
    }

    const charGalleryManageBtn = document.getElementById('char-gallery-manage-btn');
    if (charGalleryManageBtn) {
        charGalleryManageBtn.addEventListener('click', () => {
            if (typeof openGalleryManager === 'function') {
                openGalleryManager();
                showPanel('none');
            } else {
                showToast('相册功能未加载');
            }
        });
    }

    const redPacketBtn = document.getElementById('red-packet-btn');
    if (redPacketBtn) {
        redPacketBtn.addEventListener('click', () => {
            if (currentChatType !== 'group') {
                showToast('红包功能仅限群聊使用');
                return;
            }
            document.getElementById('send-red-packet-form').reset();
            document.getElementById('send-red-packet-modal').classList.add('visible');
            showPanel('none');
        });
    }

    const closeRedPacketDetailsBtn = document.getElementById('close-red-packet-details-btn');
    if (closeRedPacketDetailsBtn) {
        closeRedPacketDetailsBtn.addEventListener('click', () => {
            document.getElementById('red-packet-details-modal').classList.remove('visible');
        });
    }

    document.getElementById('send-message-btn').addEventListener('click', sendMessage);
    document.getElementById('send-message-btn').addEventListener('touchend', (e) => {
        e.preventDefault();
        sendMessage();
    });
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.isComposing && !window.UwUChatMotion95?.composing && !isGenerating) { e.preventDefault(); sendMessage(); }
    });

    // 监听输入框聚焦事件：自动收起底部面板，避免与键盘冲突
    messageInput.addEventListener('focus', () => {
        if (chatExpansionPanel.classList.contains('visible')) {
            // 立即禁用动画，防止键盘弹出时面板被顶起
            chatExpansionPanel.classList.add('no-transition');
            showPanel('none');
            // 恢复动画属性
            setTimeout(() => {
                chatExpansionPanel.classList.remove('no-transition');
            }, 100);
        }
    });

    window.SmartReplyControl?.bindInput(messageInput);
    getReplyBtn.addEventListener('click', () => getAiReply(currentChatId, currentChatType));
    regenerateBtn.addEventListener('click', handleRegenerate);
    document.getElementById('stop-generation-btn')?.addEventListener('click', stopCurrentChatGeneration);
    
    messageArea.addEventListener('click', (e) => {
        if (isDebugMode && !isInMultiSelectMode) {
            const messageWrapper = e.target.closest('.message-wrapper');
            if (messageWrapper) {
                startDebugEdit(messageWrapper.dataset.id);
                return; 
            }
        }

        if (chatExpansionPanel.classList.contains('visible')) {
            showPanel('none');
            return;
        }

        if (e.target && e.target.id === 'load-more-btn') {
            loadMoreMessages();
        } else if (isInMultiSelectMode) {
            const messageWrapper = e.target.closest('.message-wrapper');
            if (messageWrapper) {
                toggleMessageSelection(messageWrapper.dataset.id);
            }
        } else {
            const voiceChat99=(currentChatType==='private'?db.characters:db.groups).find(c=>c.id===currentChatId);
            if(window.UwUVoice98?.collapseTranscript(e.target,voiceChat99))return;
            const voiceBubble = e.target.closest('.voice-bubble');
            if (voiceBubble) {
                const transcript = voiceBubble.closest('.message-wrapper').querySelector('.voice-transcript');
                if (transcript) {
                    transcript.classList.toggle('active');
                }
            }
            
            const bilingualBubble = e.target.closest('.bilingual-bubble');
            if (bilingualBubble) {
                window.UwUBilingual113.toggle(bilingualBubble.closest('.message-wrapper'));
            }

            const pvCard = e.target.closest('.pv-card');
            if (pvCard) {
                const imageOverlay = pvCard.querySelector('.pv-card-image-overlay');
                const footer = pvCard.querySelector('.pv-card-footer');
                imageOverlay.classList.toggle('hidden');
                footer.classList.toggle('hidden');
            }
            const giftCard = e.target.closest('.gift-card');
            if (giftCard) {
                const description = giftCard.closest('.message-wrapper').querySelector('.gift-card-description');
                if (description) {
                    description.classList.toggle('active');
                }
            }
            const transferCard = e.target.closest('.transfer-card.received-transfer');
            if (transferCard && currentChatType === 'private') {
                const messageWrapper = transferCard.closest('.message-wrapper');
                const messageId = messageWrapper.dataset.id;
                const character = db.characters.find(c => c.id === currentChatId);
                const message = character.history.find(m => m.id === messageId);
                if (message && message.transferStatus === 'pending') {
                    handleReceivedTransferClick(messageId);
                }
            }
        }
    });
    
    messageArea.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        if (e.target.id === 'load-more-btn' || isInMultiSelectMode) return;
        const messageWrapper = e.target.closest('.message-wrapper');
        if (!messageWrapper) return;
        handleMessageLongPress(messageWrapper, e.clientX, e.clientY);
    });
    messageArea.addEventListener('touchstart', (e) => {
        clearTimeout(longPressTimer);
        if (e.target.id === 'load-more-btn') return;
        const messageWrapper = e.target.closest('.message-wrapper');
        if (!messageWrapper) return;
        const pressChatId=currentChatId;
        longPressTimer = setTimeout(() => {
            if(!messageWrapper.isConnected||currentChatId!==pressChatId||!e.touches.length)return;
            const touch = e.touches[0];
            handleMessageLongPress(messageWrapper, touch.clientX, touch.clientY);
        }, 400);
    });
    messageArea.addEventListener('touchend', () => clearTimeout(longPressTimer));
    messageArea.addEventListener('touchmove', () => clearTimeout(longPressTimer));
    document.addEventListener('touchcancel', () => clearTimeout(longPressTimer),true);
    window.addEventListener('blur', () => clearTimeout(longPressTimer));
    window.addEventListener('pagehide', () => clearTimeout(longPressTimer));
    document.addEventListener('visibilitychange', () => {if(document.hidden)clearTimeout(longPressTimer);});
    
    const messageEditForm = document.getElementById('message-edit-form');
    if(messageEditForm) {
        messageEditForm.addEventListener('submit', (e) => {
            e.preventDefault();
            saveMessageEdit();
        });
    }

    const cancelEditModalBtn = document.getElementById('cancel-edit-modal-btn');
    if(cancelEditModalBtn) {
        cancelEditModalBtn.addEventListener('click', cancelMessageEdit);
    }

    const hideTimestampBtn = document.getElementById('hide-timestamp-btn');
    if (hideTimestampBtn) {
        hideTimestampBtn.addEventListener('click', () => {
            if (!editingMessageId) return;
            
            const chat = (currentChatType === 'private') ? db.characters.find(c => c.id === currentChatId) : db.groups.find(g => g.id === currentChatId);
            const messageIndex = chat.history.findIndex(m => m.id === editingMessageId);
            
            let targetTime;
            if (messageIndex > 0) {
                const prevMsg = chat.history[messageIndex - 1];
                targetTime = prevMsg.timestamp + 60000; 
            } else {
                targetTime = Date.now(); 
            }
            
            const date = new Date(targetTime);
            const Y = date.getFullYear();
            const M = String(date.getMonth() + 1).padStart(2, '0');
            const D = String(date.getDate()).padStart(2, '0');
            const h = String(date.getHours()).padStart(2, '0');
            const m = String(date.getMinutes()).padStart(2, '0');
            
            const timestampInput = document.getElementById('message-edit-timestamp');
            if (timestampInput) {
                timestampInput.value = `${Y}-${M}-${D}T${h}:${m}`;
            }
        });
    }

    document.getElementById('cancel-multi-select-btn').addEventListener('click', exitMultiSelectMode);
    document.getElementById('delete-selected-btn').addEventListener('click', deleteSelectedMessages);
    document.getElementById('generate-capture-btn').addEventListener('click', generateCapture);
    document.getElementById('close-capture-modal-btn').addEventListener('click', () => {
        document.getElementById('capture-result-modal').classList.remove('visible');
    });
    document.getElementById('cancel-reply-btn').addEventListener('click', cancelQuoteReply);
}

function openChatRoom(chatId, type, options = {}) {
    window.UwUChatToolsUI?.closeComposer();
    const chat = (type === 'private') ? db.characters.find(c => c.id === chatId) : db.groups.find(g => g.id === chatId);
    if (!chat) return;

    // All entry points, including notification links, select before rendering.
    currentChatId = chat.id;
    currentChatType = type;

    // 迁移旧的私聊数据 (仅群聊)
    if (type === 'group' && chat.privateSessions && typeof migratePrivateSessionsToHistory === 'function') {
        migratePrivateSessionsToHistory(chat);
        saveData({chat}); // 迁移后立即保存
    }

    if (chat.unreadCount && chat.unreadCount > 0) {
        chat.unreadCount = 0;
        saveData({chat});
        renderChatList(); 
    }
    exitMultiSelectMode();
    cancelMessageEdit();
    chatRoomTitle.textContent = (type === 'private') ? chat.remarkName : chat.name;
    if(typeof uwuRefreshChatHeader111==='function')uwuRefreshChatHeader111(chat);
    const subtitle = document.getElementById('chat-room-subtitle');
    if (type === 'private') {
        subtitle.style.display = (chat.showStatus !== false) ? 'flex' : 'none';
        chatRoomStatusText.textContent = chat.status || '在线';
    } else {
        subtitle.style.display = 'none';
    }
    getReplyBtn.style.display = 'inline-flex';
    chatRoomScreen.style.backgroundImage = chat.chatBg ? `url(${chat.chatBg})` : 'none';
    typingIndicator.style.display = 'none';
    isGenerating = false;
    getReplyBtn.disabled = false;
    currentPage = 1;
    chatRoomScreen.className = chatRoomScreen.className.replace(/\bchat-active-[^ ]+\b/g, '');
    chatRoomScreen.classList.add(`chat-active-${chatId}`);
    
    const avatarRadius = chat.avatarRadius !== undefined ? chat.avatarRadius : 50;
    document.documentElement.style.setProperty('--chat-avatar-radius', `${avatarRadius}%`);

    if (chat.bubbleBlurEnabled === false) {
        chatRoomScreen.classList.add('disable-blur');
    } else {
        chatRoomScreen.classList.remove('disable-blur');
    }

    if (chat.showTimestamp) {
        chatRoomScreen.classList.add('show-timestamp');
    } else {
        chatRoomScreen.classList.remove('show-timestamp');
    }
    chatRoomScreen.classList.remove('timestamp-side');

    chatRoomScreen.classList.remove('timestamp-style-bubble', 'timestamp-style-avatar');
    chatRoomScreen.classList.add(`timestamp-style-${chat.timestampStyle || 'bubble'}`);

    const header = document.getElementById('chat-room-header-default');
    if (chat.titleLayout === 'center') {
        header.classList.add('title-centered');
    } else {
        header.classList.remove('title-centered');
    }

    const journalBtnLabel = document.querySelector('#memory-journal-btn .expansion-item-name');
    if (journalBtnLabel) {
        journalBtnLabel.textContent = (type === 'group') ? '总结' : '日记';
    }

    const starBtn = document.getElementById('char-status-btn');
    if (starBtn) {
        if (type === 'private' && (chat.statusPanel?.enabled || chat.statusPanel?.history?.length || db.statusThinkingEnabled)) {
            starBtn.style.display = 'flex';
        } else {
            starBtn.style.display = 'none';
        }
    }

    const redPacketBtn = document.getElementById('red-packet-btn');
    if (redPacketBtn) {
        redPacketBtn.style.display = (type === 'group') ? 'flex' : 'none';
    }

    const peekBtn = document.getElementById('peek-btn');
    if (peekBtn) {
        if (type === 'private') {
            peekBtn.style.display = 'flex';
            peekBtn.classList.remove('has-unread');
            const badge = document.getElementById('gossip-badge');
            if (badge) badge.style.display = 'none';
        } else {
            // 群聊
            if (chat.allowGossip) {
                peekBtn.style.display = 'flex';
                // 检查未读
                const hasUnread = Object.values(gossipUnreadMap || {}).some(count => count > 0);
                const badge = document.getElementById('gossip-badge');
                if (hasUnread) {
                    peekBtn.classList.add('has-unread');
                    if (badge) badge.style.display = 'block';
                } else {
                    peekBtn.classList.remove('has-unread');
                    if (badge) badge.style.display = 'none';
                }
            } else {
                peekBtn.style.display = 'none';
            }
        }
    }

    updateCustomBubbleStyle(chatId, chat.customBubbleCss, chat.useCustomBubbleCss);
    const targetIndex110 = options.messageId ? chat.history.findIndex(m => String(m.id) === String(options.messageId)) : -1;
    if (targetIndex110 >= 0) {
      const size = typeof MESSAGES_PER_PAGE !== "undefined" ? MESSAGES_PER_PAGE : 20;
      currentPage = Math.max(1, Math.ceil((chat.history.length - targetIndex110) / size));
      const start110 = Math.max(0, targetIndex110 - Math.floor(size / 2));
      window.UwUHistoryJump110 = { chatId: chat.id, type, start: start110, end: Math.min(chat.history.length, start110 + size) };
      renderMessages(false, false, { historyFocus: true });
    } else {
      window.UwUHistoryJump110 = null;
      window.UwUHistoryReturn110 = null;
      renderMessages(false, true);
    }
    switchScreen('chat-room-screen');
    if (targetIndex110 >= 0) requestAnimationFrame(() => {
      const row = Array.from(messageArea.querySelectorAll('[data-id]')).find(e => e.dataset.id === String(options.messageId));
      if (row) { row.scrollIntoView({ block: 'center', behavior: 'auto' }); row.classList.add('search-located110'); setTimeout(() => row.classList.remove('search-located110'), 2500); }
      else showToast('消息已定位到所在页，该消息类型可能已隐藏');
    });
    
    requestAnimationFrame(() => {
        void document.body.offsetHeight; 
    });
}

async function sendMessage() {
    if (window.UwUHistoryJump110) { window.UwUHistoryJump110 = null; currentPage = 1; renderMessages(false, true); }
    if(window.UwUChatMotion95?.composing)return;
    if(window.UwUChatToolsUI?.editing()){try{await window.UwUChatToolsUI.commit();}catch(e){showToast(e.message);}return;}
    if(window.UwUChatToolsUI?.hasTodoDraft109()){try{await window.UwUChatToolsUI.commitTodoDraft109();}catch(e){showToast(e.message);}return;}
    const text = messageInput.value.trim();
    if (!text || isGenerating) return;
    const textEffects95 = window.UwUChatMotion95?.consume(messageInput.value) || [];
    messageInput.value = ''; 
    const chat = (currentChatType === 'private') ? db.characters.find(c => c.id === currentChatId) : db.groups.find(g => g.id === currentChatId);

    if (!chat) return;
    if (!chat.history) chat.history = [];

    if (db.apiSettings && db.apiSettings.timePerceptionEnabled) {
        const now = new Date();
        const lastMessageTime = chat.lastUserMessageTimestamp;
        if (lastMessageTime) {
            const timeGap = now.getTime() - lastMessageTime;
            const thirtyMinutes = 30 * 60 * 1000; 

            if (timeGap > thirtyMinutes) {
                const displayContent = `[system-display:距离上次聊天已经过去 ${formatTimeGap(timeGap)}]`;
                const visualMessage = {
                    id: `msg_visual_timesense_${Date.now()}`,
                    role: 'system',
                    content: displayContent,
                    parts: [],
                    timestamp: now.getTime() - 2 
                };

                if (currentChatType === 'group') {
                    visualMessage.senderId = 'user_me';
                }

                chat.history.push(visualMessage);
                addMessageBubble(visualMessage, currentChatId, currentChatType);
            }
        }
        chat.lastUserMessageTimestamp = now.getTime();
    }

    let messageContent;
    const systemRegex = /\[system:.*?\]|\[system-display:.*?\]/;
    const inviteRegex = /\[.*?邀请.*?加入群聊\]/;
    const renameRegex = /\[(.*?)修改群名为“(.*?)”\]/;
    const shopOrderRegex = /\[.*?为你下单的商品：.*?\]/;
    const myName = (currentChatType === 'private') ? chat.myName : chat.me.nickname;

    if (renameRegex.test(text)) {
        const match = text.match(renameRegex);
        chat.name = match[2];
        chatRoomTitle.textContent = chat.name;
        messageContent = `[${chat.me.nickname}修改群名为“${chat.name}”]`;
    } else if (systemRegex.test(text) || inviteRegex.test(text) || shopOrderRegex.test(text)) {
        messageContent = text;
    } else {
        let userText = text;
        messageContent = `[${myName}的消息：${userText}]`;
    }

    const message = {
        id: `msg_${Date.now()}`,
        role: 'user',
        content: messageContent,
        parts: [{type: 'text', text: messageContent}],
        ...(textEffects95.length ? {uwuTextEffects:textEffects95} : {}),
        uwuUrgent: window.uwuUrgentNext85 === true,
        timestamp: Date.now()
    };

    if (currentQuoteInfo) {
        message.quote = {
            messageId: currentQuoteInfo.id,
            senderId: currentQuoteInfo.senderId, 
            content: currentQuoteInfo.content
        };
    }

    if (currentChatType === 'group') {
        message.senderId = 'user_me';
    }
    chat.history.push(message);
    addMessageBubble(message, currentChatId, currentChatType,{userWillSave:true});
    triggerHapticFeedback('success');

    if (chat.history.length > 0 && chat.history.length % 300 === 0) {
        promptForBackupIfNeeded('history_milestone');
    }

    try { await saveData({chat}); } catch(error) { console.error('消息保存失败',error);showToast('消息尚未保存成功，请保留应用并重试保存');return; }
    renderChatList();

    if (currentQuoteInfo) {
        cancelQuoteReply();
    }
}

// 备份提示
function promptForBackupIfNeeded(triggerType) {
    if (triggerType === 'history_milestone') {
        showToast('uwu提醒您：记得备份噢');
    }
}
