// Authorised account writes and selection provenance; no additional model call.
(() => {
'use strict';
const norm=v=>String(v||'').normalize('NFKC').toLowerCase().replace(/[\s《》“”"'’·.,，。!?！？]/g,'');
function origins(){return S.songOrigins??=load(accountKey('songOrigins.v71'),{});}
function ledger(){return S.musicLedger??=load(accountKey('actions.v73'),[]);}
function record(songs,role,space,scope,op='add',playlist=null,outcome='added'){if(!space||!songs.length)return;const entry={id:Date.now().toString(36)+Math.random().toString(36).slice(2,8),time:Date.now(),space:String(space),role,scope,op,playlist,outcome,epoch:S.togetherEpoch,songs:songs.map(s=>({id:String(s.id),title:String(s.name||s.title||'').slice(0,160),artist:(s.ar||s.artists||[]).map(a=>a.name).join('/').slice(0,160)}))};S.musicLedger=[entry,...ledger()].slice(0,600);if(S.uid)save(accountKey('actions.v73'),S.musicLedger);const who=role==='char'?profile()?.charName||profile()?.name||'对方':profile()?.userName||'你';if(scope==='queue')activity(who+(op==='remove'?'移除待播':outcome==='duplicate'?'尝试重复加入待播':'加入待播')+'：'+entry.songs.map(s=>'《'+s.title+'》').join('、'),op==='remove'?'remove':'plus',role);}
function mark(songs,role,space,pid){if(!space)return;const data=origins();for(const s of songs){const key=space+':'+s.id;if(!data[key])data[key]={role,time:Date.now(),...(pid?{playlist:String(pid)}:{})};if(!pid&&s.uwuSelection?.space!==String(space))s.uwuSelection={role,space:String(space),time:Date.now()};}S.songOrigins=Object.fromEntries(Object.entries(data).sort((a,b)=>b[1].time-a[1].time).slice(0,2000));if(S.uid)save(accountKey('songOrigins.v71'),S.songOrigins);record(songs,role,space,pid?'playlist':'queue','add',pid?String(pid):null);}
function credit(song,source,operator){const p=profile(),space=S.activeId||p?.id,entry=origins()[space+':'+song.id];let role=song.uwuSelection?.space===String(space)?song.uwuSelection.role:entry?.role;if(!role&&source?.id&&String(source.id)===String(p?.exclusivePid||''))role='char';if(!role&&source?.kind==='char-radio'&&String(source.charId)===String(space))role='char';role??=operator;return {role,name:role==='char'?p?.charName||p?.name||'对方':role==='user'?p?.userName||'你':'自动播放'};}
function recent(space,since=0){const groups=[];for(const e of ledger().filter(e=>e.space===String(space)&&e.time>=since)){const prev=groups.at(-1),key=[e.role,e.scope,e.op,e.playlist,e.outcome,e.epoch].join(':');if(prev&&prev.key===key&&prev.time-e.time<5000){prev.count+=e.songs.length;prev.songs.push(...e.songs);prev.songs=prev.songs.slice(0,12);}else{if(groups.length>=6)break;groups.push({...e,key,count:e.songs.length,songs:e.songs.slice(0,12)});}}return groups.map(({key,...e})=>e);}
function artistMatch(song,who){const names=(song.ar||song.artists||[]).map(a=>norm(a.name));if(names.includes(norm(who)))return true;const parts=String(who).split(/\s*(?:\/|、|,|，|&|＆)\s*/).map(norm).filter(Boolean);return parts.length>1&&parts.every(p=>names.includes(p));}
const originalLoad=storageLoad;storageLoad=function(){originalLoad();S.songOrigins=load(accountKey('songOrigins.v71'),{});S.musicLedger=load(accountKey('actions.v73'),[]);};
function targetFor(a){const p=profile(),role=a.playlistRole||a.saveTo;if(role&&!['exclusive','common'].includes(role))throw Error('歌单类型无效');const roleId=role==='exclusive'?p?.exclusivePid:role==='common'?p?.defaultPid:null;if(role&&!roleId)throw Error(role==='exclusive'?'尚未绑定专属歌单':'尚未绑定共同歌单');if(roleId&&a.playlistId&&String(roleId)!==String(a.playlistId))throw Error('歌单编号与类型不一致');const id=String(a.playlistId||roleId||p?.defaultPid||''),target=p?.items.find(x=>String(x.pid)===id);if(!target||playlistPermissions(p,target)[a.type==='remove'?'remove':'add']!==true)throw Error('目标歌单未授权此操作');return {id,name:target.name};}
function stamp(extra=()=>true){const owner=S.activeId,epoch=S.epoch,together=S.togetherEpoch;return ()=>extra()&&!!owner&&S.activeId===owner&&S.epoch===epoch&&S.togetherEpoch===together;}
async function resolveOne(track,valid,signal){if(track.id||track.songId){const id=String(track.id||track.songId);if(!/^\d+$/.test(id))throw Error('歌曲编号无效');const d=check((await api('details',{ids:[id]},signal)).result);if(!valid())throw Error('一起听状态已变化');const s=d.songs?.find(s=>String(s.id)===id);if(!s)throw Error('未找到该歌曲');return s;}
 const title=String(track.title||track.name||'').trim(),who=String(track.artist||'').trim();if(!title||title.length>160||who.length>160)throw Error('请提供明确歌名和歌手');const d=check((await api('search',{keyword:[title,who].filter(Boolean).join(' ')},signal)).result);if(!valid())throw Error('一起听状态已变化');const rows=(d.result?.songs||d.songs||[]).filter(s=>norm(s.name)===norm(title)&&(!who||artistMatch(s,who)));const unique=[...new Map(rows.map(s=>[String(s.id),s])).values()];if(!unique.length)throw Error('未准确匹配到歌名与歌手');
 // A requested artist stays authoritative, including intentional covers. Prefer
 // studio releases among duplicate album IDs, then preserve search relevance.
 if(!who&&new Set(unique.map(s=>(s.ar||s.artists||[]).map(a=>norm(a.name)).sort().join('/'))).size>1)throw Error('同名歌曲有不同歌手，请提供歌手');
 const variant=/\blive\b|演唱会|现场|伴奏|卡拉|instrumental|karaoke|remix|混音|重混/i;
 const requestedVariant=variant.test(title);
 const ranked=unique.map((song,index)=>({song,index,score:!requestedVariant&&variant.test(String(song.al?.name||song.album?.name||''))?1:0})).sort((a,b)=>a.score-b.score||a.index-b.index);
 return ranked[0].song;}
// Sharing resolves display aliases without relaxing playlist-write selection.
const shareVariant95=/live|现场|演唱会|伴奏|instrumental|karaoke|remix|混音|重混/i;
function shareTitle95(name){return norm(String(name||'').replace(/[（(]([^()（）]*)[）)]/g,(full,inside)=>shareVariant95.test(inside)?full:''));}
function shareArtist95(song,who){
 if(artistMatch(song,who))return true;
 const aliases=name=>{const text=String(name||'').normalize('NFKC');return [norm(text),...text.match(/[\p{Script=Han}]{2,}|[A-Za-z][A-Za-z .'-]{2,}/gu)||[]].map(norm).filter(Boolean);};
 const wanted=aliases(who);return (song.ar||song.artists||[]).some(a=>aliases(a.name).some(x=>wanted.includes(x)));
}
async function resolveShared95(track,valid){
 if(track.id||track.songId)return resolveOne(track,valid);
 const title=String(track.title||track.name||'').trim(),who=String(track.artist||'').trim();
 if(!title||title.length>160||who.length>160)throw Error('请提供明确歌名和歌手');
 let candidates=[];
 const compatible=s=>shareTitle95(s.name)===shareTitle95(title)&&(!who||shareArtist95(s,who));
 for(const keyword of [...new Set([[title,who].filter(Boolean).join(' '),title])]){
  const d=check((await api('search',{keyword})).result);if(!valid())throw Error('歌曲卡片已失效');
  candidates.push(...(d.result?.songs||d.songs||[]));if(candidates.some(compatible))break;
 }
 const rows=[...new Map(candidates.filter(compatible).map(s=>[String(s.id),s])).values()];
 if(!rows.length)throw Error('未找到匹配的歌曲：'+title+(who?' · '+who:''));
 if(!who&&new Set(rows.map(s=>(s.ar||s.artists||[]).map(a=>norm(a.name)).sort().join('/'))).size>1)throw Error('有多位歌手演唱同名歌曲，请补充歌手');
 rows.sort((a,b)=>Number(norm(b.name)===norm(title))-Number(norm(a.name)===norm(title))||Number(shareVariant95.test(a.al?.name||a.album?.name||''))-Number(shareVariant95.test(b.al?.name||b.album?.name||'')));
 return rows[0];
}
async function collect(a,provided){const valid=stamp(a._valid),owner=S.activeId,target=targetFor(a);if(!valid())throw Error('一起听未开启');let specs=provided||a.tracks||a.songIds?.map(id=>({id}));if(!specs)specs=a.songId?[{id:a.songId}]:a.title?[{title:a.title,artist:a.artist}]:now()?[now()]:[];if(!Array.isArray(specs)||!specs.length||specs.length>12)throw Error('每次收藏1至12首明确歌曲');const saved=[],failed=[],seen=new Set();for(const spec of specs){if(!valid())throw Error('一起听状态已变化');try{const cached=provided&&S.queue.find(s=>String(s.id)===String(spec.id));const song=cached||await resolveOne(spec,valid);if(seen.has(String(song.id)))continue;seen.add(String(song.id));if(!valid())throw Error('一起听状态已变化');const role=a.playlistRole||a.saveTo;if(role&&String(role==='exclusive'?profile()?.exclusivePid:profile()?.defaultPid)!==target.id)throw Error('歌单绑定已变化，操作已停止');await writeTrack(a.type==='remove'?'remove':'add',song,target,'char',owner,valid);saved.push({id:String(song.id),name:song.name});}catch(e){if(!valid())throw e;failed.push({title:String(spec.title||spec.name||spec.id||'').slice(0,100),reason:String(e.message).slice(0,120)});}}
 if(!saved.length)throw Error(failed[0]?.reason||'歌单未写入');return {ok:true,playlist:target.name,playlistRole:a.playlistRole||a.saveTo||'linked',saved:saved.length,songs:saved.slice(0,3),failed,partial:failed.length>0};}
const originalRun=UwUMusic.runCharAction;
UwUMusic.runCharAction=async function(a){if(a.type==='add'||a.type==='remove')return collect(a);if(a.type==='radio'){if(a.saveTo)targetFor({...a,type:'add'});const result=await radioQueue.start(a.tracks,a.append!==false&&!!now(),{singleArtist:a._allowSingleArtist===true,valid:a._valid});if(a.saveTo&&result.songIds?.length){try{const collected=await collect({type:'add',playlistRole:a.saveTo,_valid:a._valid},result.songIds.map(id=>({id})));return {...result,...collected,added:result.added,partial:!!result.partial||!!collected.partial};}catch(e){return {...result,saved:0,failed:[{reason:e.message}],partial:true};}}return result;}return originalRun(a);};
window.UwUMusicActions={mark,credit,collect,record,recent,resolveOne,resolveShared95};
})();
